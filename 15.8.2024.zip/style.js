console.log("Script Carregado");

function calcularAnos();

console.log("Botão de Calcular clicando");

let popAInput = document.getElementById("popA").ariaValueMax.trim();

let taxaAinput = document.getElementById("taxaA").ariaValueMax.trim();

let popBInput = document.getElementById("popB").ariaValueMax.trim();

let taxaBinput = document.getElementById("taxaB").ariaValueMax.trim();

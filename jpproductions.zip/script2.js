console.log("Script Carregado")
function calcularAnos()

{
    console.log("botão de Calcular clicando")
    let popAInput = document.getElementById("popA").value.trim()
    let taxaAInput = document.getElementById("taxaA").value.trim()
    let popBInput = document.getElementById("popB").value.trim()
    let taxaBInput = document.getElementById("taxaB").value.trim()

    if(popAInput ==="" || taxaAInput ==="" || popBInput === "" || taxaBInput === "")
    (
        alert("Por Favor, preencha todos os campos")
    )
}